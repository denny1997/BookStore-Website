﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;
using BookWeb.Models;

namespace BookWeb.Controllers
{
    public class OrdersManageController : Controller
    {
        private userAccount user_db = new userAccount();
        private bookInfo book_db = new bookInfo();
        private orderInfo order_db = new orderInfo();
        private ask_for_bookInfo ask_book_db = new ask_for_bookInfo();
        private ask_for_orderInfo ask_order_db = new ask_for_orderInfo();

        // GET: OrdersManage
        public ActionResult OrderConfirm(int? id)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login","UserAccount");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            book book = book_db.books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OrderConfirm([Bind(Include = "orderId,seller,buyer,book,number,type")] order order)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (ModelState.IsValid)
            {   
                if(order.type==0)
                {
                    user buyer = user_db.users.Find(order.buyer);
                    user seller = user_db.users.Find(order.seller);                   
                    if((buyer==null)||(seller==null))
                    {
                        MessageBox.Show("交易信息出现错误", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                        return RedirectToAction("OrderConfirm",new { id = order.book});
                    }
                    book book = book_db.books.Find(order.book);
                    int total = book.curPrice * order.number;
                    if (buyer.account<total)
                    {
                        MessageBox.Show("余额不足，请联系对方或选择线下交易", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                        return RedirectToAction("OrderConfirm", new { id = order.book });
                    }
                    buyer.account -= total;
                    seller.account += total;
                    user_db.Entry(buyer).State = EntityState.Modified;
                    user_db.Entry(seller).State = EntityState.Modified;
                    user_db.SaveChanges();
                    book.stock -= order.number;
                    book_db.Entry(book).State = EntityState.Modified;
                    book_db.SaveChanges();
                    order_db.orders.Add(order);
                    order_db.SaveChanges();
                    MessageBox.Show("购买成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("Index","BookManage");
                }
                else
                {
                    book book = book_db.books.Find(order.book);
                    book.stock -= order.number;
                    book_db.Entry(book).State = EntityState.Modified;
                    book_db.SaveChanges();
                    order_db.orders.Add(order);
                    order_db.SaveChanges();
                    MessageBox.Show("购买成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("Index", "BookManage");
                }                
            }
            else
            {
                MessageBox.Show("购买失败", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("OrderConfirm", new { id = order.book });
            }            
        }

        public ActionResult AskOrderConfirm(int? id)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ask_for_book book = ask_book_db.ask_for_book.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AskOrderConfirm([Bind(Include = "orderId,seller,buyer,book,number,type")] ask_for_order order)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (ModelState.IsValid)
            {
                if (order.type == 0)
                {
                    user buyer = user_db.users.Find(order.buyer);
                    user seller = user_db.users.Find(order.seller);
                    if ((buyer == null) || (seller == null))
                    {
                        MessageBox.Show("交易信息出现错误", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                        return RedirectToAction("AskOrderConfirm", new { id = order.book });
                    }
                    ask_for_book book = ask_book_db.ask_for_book.Find(order.book);
                    int total = int.Parse(book.price) * order.number;
                    if (buyer.account < total)
                    {
                        MessageBox.Show("对方余额不足，请联系对方或选择线下交易", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                        return RedirectToAction("AskOrderConfirm", new { id = order.book });
                    }
                    buyer.account -= total;
                    seller.account += total;
                    user_db.Entry(buyer).State = EntityState.Modified;
                    user_db.Entry(seller).State = EntityState.Modified;
                    user_db.SaveChanges();
                    book.number -= order.number;
                    ask_book_db.Entry(book).State = EntityState.Modified;
                    ask_book_db.SaveChanges();
                    ask_order_db.ask_for_order.Add(order);
                    ask_order_db.SaveChanges();
                    MessageBox.Show("出售成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("Index", "BookManage");
                }
                else
                {
                    ask_for_book book = ask_book_db.ask_for_book.Find(order.book);
                    book.number -= order.number;
                    ask_book_db.Entry(book).State = EntityState.Modified;
                    ask_book_db.SaveChanges();
                    ask_order_db.ask_for_order.Add(order);
                    ask_order_db.SaveChanges();
                    MessageBox.Show("出售成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("Index", "BookManage");
                }
            }
            else
            {
                MessageBox.Show("出售失败", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("AskOrderConfirm", new { id = order.book });
            }
        }

        public ActionResult AddShoppingCart(int? id)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            book book = book_db.books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddShoppingCart(int book,int number)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            user user = (user)Session["user"];
            ShoppingCartItem sci = new ShoppingCartItem();
            sci.itemId = book;
            sci.itemNum = number;
            ShoppingCart sc;
            if (Request.Cookies[user.userId.ToString()]==null)
            {               
                sc = new ShoppingCart();
                sc.items = new List<ShoppingCartItem>();
                sc.items.Add(sci);
            }
            else
            {
                string _result = Request.Cookies[user.userId.ToString()].Value;
                byte[] b = Convert.FromBase64String(_result);  //将得到的字符串根据相同的编码格式分成字节数组
                MemoryStream _ms = new MemoryStream(b, 0, b.Length);  //从字节数组中得到内存流
                BinaryFormatter _bf = new BinaryFormatter();
                sc = _bf.Deserialize(_ms) as ShoppingCart;  //反序列化得到Person类对象
                foreach(var item in sc.items)
                {
                    if (item.itemId == sci.itemId)
                    {
                        sc.items.Remove(item);                       
                        break;
                    }                        
                }
                sc.items.Add(sci);
            }
            BinaryFormatter bf = new BinaryFormatter();  //声明一个序列化类
            MemoryStream ms = new MemoryStream();  //声明一个内存流
            bf.Serialize(ms, sc);  //执行序列化操作
            byte[] result = new byte[ms.Length];
            result = ms.ToArray();
            string temp = Convert.ToBase64String(result);
            ms.Flush();
            ms.Close();
            HttpCookie cookie = new HttpCookie(user.userId.ToString());  //声明一个Key为person的Cookie对象
            cookie.Expires = DateTime.Now.AddDays(1.0);  //设置Cookie的有效期到明天为止,此处时间可以根据需要设置
            cookie.Value = temp;  //将cookie的Value值设置为temp
            Response.Cookies.Add(cookie);
            MessageBox.Show("添加成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            return RedirectToAction("Index", "BookManage");
        }

        public ActionResult ShowShoppingCart()
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            user user = (user)Session["user"];
            List<Tuple<book,int>> books = new List<Tuple<book,int>>();
            if (Request.Cookies[user.userId.ToString()] != null)
            {
                string _result = Request.Cookies[user.userId.ToString()].Value;
                byte[] b = Convert.FromBase64String(_result);  //将得到的字符串根据相同的编码格式分成字节数组
                MemoryStream _ms = new MemoryStream(b, 0, b.Length);  //从字节数组中得到内存流
                BinaryFormatter _bf = new BinaryFormatter();
                ShoppingCart sc = _bf.Deserialize(_ms) as ShoppingCart;  //反序列化得到Person类对象              
                foreach(ShoppingCartItem temp in sc.items)
                {
                    book t = book_db.books.Find(temp.itemId);
                    books.Add(Tuple.Create(t, temp.itemNum));
                }
            }
            return View(books);
        }

        public ActionResult DeleteShoppingItem(int id)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            user user = (user)Session["user"];            
            if (Request.Cookies[user.userId.ToString()] != null)
            {
                string _result = Request.Cookies[user.userId.ToString()].Value;
                byte[] b = Convert.FromBase64String(_result);  //将得到的字符串根据相同的编码格式分成字节数组
                MemoryStream _ms = new MemoryStream(b, 0, b.Length);  //从字节数组中得到内存流
                BinaryFormatter _bf = new BinaryFormatter();
                ShoppingCart sc = _bf.Deserialize(_ms) as ShoppingCart;  //反序列化得到Person类对象              
                foreach (ShoppingCartItem temp in sc.items)
                {
                    if(temp.itemId == id)
                    {
                        sc.items.Remove(temp);
                        break;
                    }
                }
                BinaryFormatter bf = new BinaryFormatter();  //声明一个序列化类
                MemoryStream ms = new MemoryStream();  //声明一个内存流
                bf.Serialize(ms, sc);  //执行序列化操作
                byte[] result = new byte[ms.Length];
                result = ms.ToArray();
                string _temp = Convert.ToBase64String(result);
                ms.Flush();
                ms.Close();
                HttpCookie cookie = new HttpCookie(user.userId.ToString());  //声明一个Key为person的Cookie对象
                cookie.Expires = DateTime.Now.AddDays(1.0);  //设置Cookie的有效期到明天为止,此处时间可以根据需要设置
                cookie.Value = _temp;  //将cookie的Value值设置为temp
                Response.Cookies.Add(cookie);
                //MessageBox.Show("删除成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);                
            }
            return RedirectToAction("ShowShoppingCart");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ShoppingCartOrder([Bind(Include = "orderId,seller,buyer,book,number,type")] order order)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (ModelState.IsValid)
            {                
                user buyer = user_db.users.Find(order.buyer);
                user seller = user_db.users.Find(order.seller);
                if ((buyer == null) || (seller == null))
                {
                    MessageBox.Show("交易信息出现错误", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("ShowShoppingCart");
                }
                book book = book_db.books.Find(order.book);
                int total = book.curPrice * order.number;
                if (buyer.account < total)
                {
                    MessageBox.Show("余额不足，请联系对方或选择线下交易", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("ShowShoppingCart");
                }
                buyer.account -= total;
                seller.account += total;
                user_db.Entry(buyer).State = EntityState.Modified;
                user_db.Entry(seller).State = EntityState.Modified;
                user_db.SaveChanges();
                book.stock -= order.number;
                book_db.Entry(book).State = EntityState.Modified;
                book_db.SaveChanges();
                order_db.orders.Add(order);
                order_db.SaveChanges();
                MessageBox.Show("购买成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("DeleteShoppingItem", "OrdersManage", new { id = order.book});              
            }
            else
            {
                MessageBox.Show("购买失败", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("ShowShoppingCart");
            }
        }

        public ActionResult ShoppingCartAllOrders(int total)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            user user = (user)Session["user"];
            if(total>user.account)
            {
                MessageBox.Show("余额不足", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("ShowShoppingCart");
            }
            if (Request.Cookies[user.userId.ToString()] != null)
            {
                string _result = Request.Cookies[user.userId.ToString()].Value;
                byte[] b = Convert.FromBase64String(_result);  //将得到的字符串根据相同的编码格式分成字节数组
                MemoryStream _ms = new MemoryStream(b, 0, b.Length);  //从字节数组中得到内存流
                BinaryFormatter _bf = new BinaryFormatter();
                ShoppingCart sc = _bf.Deserialize(_ms) as ShoppingCart;  //反序列化得到Person类对象              
                foreach (ShoppingCartItem temp in sc.items)
                {
                    book t = book_db.books.Find(temp.itemId);
                    order order = new order();
                    order.seller = t.sellerId;
                    order.buyer = user.userId;
                    order.book = t.bookId;
                    order.number = temp.itemNum;
                    order.type = 0;

                    user buyer = user_db.users.Find(order.buyer);
                    user seller = user_db.users.Find(order.seller);
                    if ((buyer == null) || (seller == null))
                    {
                        MessageBox.Show("交易信息出现错误", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                        return RedirectToAction("ShowShoppingCart");
                    }
                    buyer.account -= total;
                    seller.account += total;
                    user_db.Entry(buyer).State = EntityState.Modified;
                    user_db.Entry(seller).State = EntityState.Modified;
                    user_db.SaveChanges();
                    t.stock -= order.number;
                    book_db.Entry(t).State = EntityState.Modified;
                    book_db.SaveChanges();
                    order_db.orders.Add(order);
                    order_db.SaveChanges();
                    //MessageBox.Show("购买成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    //return RedirectToAction("DeleteShoppingItem", "OrdersManage", new { id = order.book });
                }
                HttpCookie cookie = new HttpCookie(user.userId.ToString());  //声明一个Key为person的Cookie对象
                cookie.Expires = DateTime.Now.AddDays(-1.0);  //设置Cookie的有效期到明天为止,此处时间可以根据需要设置                
                Response.Cookies.Add(cookie);
                MessageBox.Show("购买成功", "订单提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);              
            }
            return RedirectToAction("ShowShoppingCart");
        }
    }
}
