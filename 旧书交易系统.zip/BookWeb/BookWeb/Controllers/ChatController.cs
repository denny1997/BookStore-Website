﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;
using BookWeb.Models;

namespace BookWeb.Controllers
{
    public class ChatController : Controller
    {
        // GET: Chat
        public ActionResult ChatRoom(int seller,int book)
        {
            if (Session["user"] == null)
                return RedirectToAction("Login", "UserAccount");
            user user = (user)Session["user"];
            if (HttpContext.Application[user.userId.ToString()].ToString() != "0")
            {
                MessageBox.Show("请先处理未接收的聊天邀请", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("BookInfo", "BookManage", new { id = book });
            }
            if (user.userId==seller)
            {
                MessageBox.Show("这本书是当前用户发布的", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("BookInfo", "BookManage", new { id = book });
            }
            if (HttpContext.Application[seller.ToString()]==null)
            {
                MessageBox.Show("对方不在线", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("BookInfo", "BookManage",new { id = book});
            }
            else
            {
                string sellerState = HttpContext.Application[seller.ToString()].ToString();
                if(sellerState!="0")
                {
                    MessageBox.Show("对方正忙", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("BookInfo", "BookManage", new { id = book });
                }
                else
                {                    
                    HttpContext.Application[seller.ToString()] = user.userId.ToString();
                    HttpContext.Application[user.userId.ToString()] = seller.ToString();
                    return View(Tuple.Create(user.userId,seller));
                }
            }                        
        }

        public ActionResult AcceptChatRoom()
        {
            if (Session["user"] == null)
                return RedirectToAction("Login", "UserAccount");
            user user = (user)Session["user"];
            if(HttpContext.Application[HttpContext.Application[user.userId.ToString()].ToString()]==null)
            {
                //MessageBox.Show("邀请已过期", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);                
                HttpContext.Application[user.userId.ToString()] = "0";
                //return RedirectToAction("Index", "BookManage");
                return Content("邀请已过期");
            }
            if(HttpContext.Application[HttpContext.Application[user.userId.ToString()].ToString()].ToString()!= user.userId.ToString())
            {
                //MessageBox.Show("邀请已过期", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);               
                HttpContext.Application[user.userId.ToString()] = "0";
                //return RedirectToAction("Index", "BookManage");
                return Content("邀请已过期");
            }
            else
            {
                return View("ChatRoom",Tuple.Create(user.userId, int.Parse(HttpContext.Application[user.userId.ToString()].ToString())));
            }
        }

        public ActionResult ExitChat()
        {
            if(Session["user"]!=null)
            {
                user user = (user)Session["user"];
                HttpContext.Application[user.userId.ToString()] = "0";
            }           
            return RedirectToAction("Index", "UserAccount");
        }
    }
}