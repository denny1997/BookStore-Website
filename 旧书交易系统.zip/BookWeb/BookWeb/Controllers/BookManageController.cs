﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;
using BookWeb.Models;
using PagedList;

namespace BookWeb.Controllers
{
    public class BookManageController : Controller
    {
        private bookInfo db = new bookInfo();
        private ask_for_bookInfo ask_for_db = new ask_for_bookInfo();

        // GET: BookManage
        public ActionResult AddBook()
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            return View();
        }

        // POST: BookManage/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddBook([Bind(Include = "bookId,bookName,oriPrice,curPrice,category,intro,ISBN,picUrl,sellerId,stock")] book book)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (ModelState.IsValid)
            {
                HttpPostedFileBase f = Request.Files["pic"];
                //string a = Server.MapPath("~/") + book.picUrl;
                f.SaveAs(Server.MapPath("~/") + book.picUrl);
                db.books.Add(book);
                db.SaveChanges();
                MessageBox.Show("书籍发布成功", "发布提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("AddBook");
            }
            else
            {
                MessageBox.Show("书籍发布失败", "发布提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            }
            return View(book);
        }

        public ActionResult AddAskForBook()
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            return View();
        }

        [HttpPost]
        public ActionResult AddAskForBook([Bind(Include = "bookid,bookName,price,comment,ISBN,picUrl,askerId,number")] ask_for_book book)
        {
            if (Session["user"] == null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login", "UserAccount");
            }
            if (ModelState.IsValid)
            {
                HttpPostedFileBase f = Request.Files["pic"];
                //string a = Server.MapPath("~/") + book.picUrl;                
                f.SaveAs(Server.MapPath("~/") + book.picUrl);
                ask_for_db.ask_for_book.Add(book);
                ask_for_db.SaveChanges();
                MessageBox.Show("求购信息发布成功", "发布提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("AddAskForBook");
            }
            else
            {
                MessageBox.Show("求购信息发布失败", "发布提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            }
            return View();
        }

        public ActionResult Index()
        {
            const int pageItem = 5;
            IPagedList<book> pageBooks = db.books.Where(c => c.stock > 0).OrderByDescending(p => p.bookId).ToPagedList(1, pageItem);
            IPagedList<ask_for_book> pageAskForBooks = ask_for_db.ask_for_book.Where(c => c.number > 0).OrderByDescending(p => p.bookid).ToPagedList(1, pageItem);
            return View(Tuple.Create(pageBooks, pageAskForBooks));
        }

        [HttpGet]
        public ActionResult BookSearch(string category, string searchString, string sortBy, int? page, string ISBN)
        {
            SearchInfo info = new SearchInfo(category, searchString, ISBN, sortBy);
            var books = db.books.AsQueryable();
            books = books.Where(c => c.stock > 0);
            int curPage = (page ?? 1);
            if (!String.IsNullOrEmpty(category))
            {
                books = books.Where(c => c.category == category);
            }
            if (!String.IsNullOrEmpty(searchString))
            {
                books = books.Where(s => s.bookName.Contains(searchString));
            }
            if (!String.IsNullOrEmpty(ISBN))
            {
                books = books.Where(s => s.ISBN.Contains(ISBN));
            }
            if ((String.IsNullOrEmpty(sortBy)) || (sortBy == "0"))
            {
                books = books.OrderBy(p => p.curPrice);
            }
            else
            {
                books = books.OrderByDescending(p => p.curPrice);
            }
            const int pageItem = 5;
            IPagedList<book> pageBooks = books.ToPagedList(curPage, pageItem);
            return View(Tuple.Create(pageBooks, info));
        }

        [HttpGet]
        public ActionResult AskForBookSearch(string ISBN, string searchString, string sortBy, int? page)
        {
            SearchInfo info = new SearchInfo(searchString, ISBN, sortBy);
            var books = ask_for_db.ask_for_book.AsQueryable();
            books = books.Where(c => c.number > 0);
            int curPage = (page ?? 1);
            if (!String.IsNullOrEmpty(ISBN))
            {
                books = books.Where(c => c.ISBN.Contains(ISBN));
            }
            if (!String.IsNullOrEmpty(searchString))
            {
                books = books.Where(s => s.bookName.Contains(searchString));
            }
            if ((String.IsNullOrEmpty(sortBy)) || (sortBy == "0"))
            {
                books = books.OrderBy(p => p.price);
            }
            else
            {
                books = books.OrderByDescending(p => p.price);
            }
            const int pageItem = 5;
            IPagedList<ask_for_book> pageBooks = books.ToPagedList(curPage, pageItem);
            return View(Tuple.Create(pageBooks, info));
        }

        public ActionResult BookInfo(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            book book = db.books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        public ActionResult AskBookInfo(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ask_for_book ask_for_book = ask_for_db.ask_for_book.Find(id);
            if (ask_for_book == null)
            {
                return HttpNotFound();
            }
            return View(ask_for_book);
        }
    }
}
