﻿using BookWeb.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace BookWeb.Controllers
{
    public class UserAccountController : Controller
    {
        private userAccount db = new userAccount();
        // GET: UserAccount

        public ActionResult Index()
        {
            if(Session["user"]==null)
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login");
            }
            user _user = (user)Session["user"];
            user user = db.users.Find(_user.userId);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            if ((username == "") || (password == ""))
            {
                MessageBox.Show("用户名或者密码不能为空", "登录提示",MessageBoxButtons.OK,MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login");
            }
            else
            {
                foreach (var i in db.users.ToList())
                {
                    if ((i.username == username) && (i.password == password))
                    {
                        MessageBox.Show("登录成功", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                        Session["user"] = i;
                        ViewBag.user = i.userId;
                        HttpContext.Application[i.userId.ToString()] = "0";
                        //Session["userid"] = i.userId;
                        return RedirectToAction("Index");
                    }
                }
                MessageBox.Show("用户名或者密码错误", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login");
            }
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register([Bind(Include = "username,password,email,usertype,account")] user Account)
        {
            foreach (var i in db.users.ToList())
            {
                if (i.username == Account.username)
                {
                    MessageBox.Show("用户名已被注册", "注册提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("Register");
                }
                else if (i.email == Account.email)
                {
                    MessageBox.Show("邮箱已被注册", "注册提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("Register");
                }
            }
            if (ModelState.IsValid)
            {
                db.users.Add(Account);
                db.SaveChanges();
                //Session["dbuser"] = dbAccount.loginName;
                MessageBox.Show("注册成功", "注册提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login");
            }
            //var errors = ModelState.Values.SelectMany(v => v.Errors);
            MessageBox.Show("注册失败", "注册提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            return RedirectToAction("Register");
        }

        public ActionResult Logout()
        {
            MessageBox.Show("注销成功", "注销提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            if(Session["user"]!=null)
            {
                user user = (user)Session["user"];
                HttpContext.Application[user.userId.ToString()]=null;
                Session["user"] = null;
            }
            //Session["userid"] = null;
            HttpContext.Application[ViewBag.user] = null;
            return RedirectToAction("Login");           
        }

        public ActionResult ChangeInfo()
        {
            if (Session["user"] == null) 
            {
                MessageBox.Show("请先登录", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                return RedirectToAction("Login");
            }
            /*user user = db.users.Find(Session["user"] as );
            if (user == null)
            {
                return HttpNotFound();
            }*/
            return View(Session["user"] as user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangeInfo([Bind(Include = "userId,username,password,email,usertype,account")] user user)
        {
            foreach (var i in db.users.AsNoTracking().ToList())
            {
                if ((i.username == user.username)&&(i.userId!=user.userId))
                {
                    MessageBox.Show("用户名已被注册", "修改提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("ChangeInfo");
                }
                else if ((i.email == user.email)&&(i.userId!=user.userId))
                {
                    MessageBox.Show("邮箱已被注册", "修改提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return RedirectToAction("ChangeInfo");
                }
            }
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                MessageBox.Show("修改成功", "修改提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                Session["user"] = user;
                return RedirectToAction("Index");
            }
            MessageBox.Show("修改失败", "修改提示", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            return RedirectToAction("ChangeInfo");
        }
    }
}