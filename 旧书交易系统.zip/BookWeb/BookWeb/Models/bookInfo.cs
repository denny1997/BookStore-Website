namespace BookWeb.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class bookInfo : DbContext
    {
        public bookInfo()
            : base("name=bookInfo")
        {
        }

        public virtual DbSet<book> books { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<book>()
                .Property(e => e.bookName)
                .IsUnicode(false);

            modelBuilder.Entity<book>()
                .Property(e => e.category)
                .IsUnicode(false);

            modelBuilder.Entity<book>()
                .Property(e => e.intro)
                .IsUnicode(false);

            modelBuilder.Entity<book>()
                .Property(e => e.ISBN)
                .IsUnicode(false);

            modelBuilder.Entity<book>()
                .Property(e => e.picUrl)
                .IsUnicode(false);
        }
    }
}
