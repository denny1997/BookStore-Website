﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookWeb.Models
{
    public class SearchInfo
    {
        public string category { set; get; }
        public string searchString { set; get; }
        public string ISBN { set; get; }
        public string sortBy { set; get; }

        public SearchInfo(string category,string searchString,string ISBN,string sortBy)
        {
            this.category = category;
            this.searchString = searchString;
            this.ISBN = ISBN;
            this.sortBy = sortBy;
        }

        public SearchInfo(string searchString, string ISBN, string sortBy)
        {
            this.searchString = searchString;
            this.ISBN = ISBN;
            this.sortBy = sortBy;
        }
    }
}