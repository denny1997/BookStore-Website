namespace BookWeb.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("bookweb.ask_for_book")]
    public partial class ask_for_book
    {
        [Key]
        public int bookid { get; set; }

        [Required]
        [StringLength(45)]
        public string bookName { get; set; }

        [Required]
        [StringLength(45)]
        public string price { get; set; }

        [Required]
        [StringLength(200)]
        public string comment { get; set; }

        [Required]
        [StringLength(45)]
        public string ISBN { get; set; }

        [Required]
        [StringLength(45)]
        public string picUrl { get; set; }

        public int askerId { get; set; }

        public int number { get; set; }
    }
}
