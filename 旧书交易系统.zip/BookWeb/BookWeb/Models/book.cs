namespace BookWeb.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("bookweb.book")]
    public partial class book
    {
        public int bookId { get; set; }

        [Required]
        [StringLength(45)]
        public string bookName { get; set; }

        public int oriPrice { get; set; }

        public int curPrice { get; set; }

        [Required]
        [StringLength(45)]
        public string category { get; set; }

        [Required]
        [StringLength(200)]
        public string intro { get; set; }

        [Required]
        [StringLength(45)]
        public string ISBN { get; set; }

        [Required]
        [StringLength(45)]
        public string picUrl { get; set; }

        public int sellerId { get; set; }

        public int stock { get; set; }
    }
}
