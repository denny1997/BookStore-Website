namespace BookWeb.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("bookweb.ask_for_order")]
    public partial class ask_for_order
    {
        [Key]
        public int orderId { get; set; }

        public int seller { get; set; }

        public int buyer { get; set; }

        public int book { get; set; }

        public int number { get; set; }

        public int type { get; set; }
    }
}
