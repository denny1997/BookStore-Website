namespace BookWeb.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ask_for_orderInfo : DbContext
    {
        public ask_for_orderInfo()
            : base("name=ask_for_orderInfo")
        {
        }

        public virtual DbSet<ask_for_order> ask_for_order { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
