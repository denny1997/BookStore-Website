namespace BookWeb.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ask_for_bookInfo : DbContext
    {
        public ask_for_bookInfo()
            : base("name=ask_for_bookInfo")
        {
        }

        public virtual DbSet<ask_for_book> ask_for_book { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ask_for_book>()
                .Property(e => e.bookName)
                .IsUnicode(false);

            modelBuilder.Entity<ask_for_book>()
                .Property(e => e.price)
                .IsUnicode(false);

            modelBuilder.Entity<ask_for_book>()
                .Property(e => e.comment)
                .IsUnicode(false);

            modelBuilder.Entity<ask_for_book>()
                .Property(e => e.ISBN)
                .IsUnicode(false);

            modelBuilder.Entity<ask_for_book>()
                .Property(e => e.picUrl)
                .IsUnicode(false);
        }

        public System.Data.Entity.DbSet<BookWeb.Models.book> books { get; set; }
    }
}
