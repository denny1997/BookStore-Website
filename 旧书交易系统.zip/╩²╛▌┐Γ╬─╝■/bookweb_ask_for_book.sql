-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: bookweb
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ask_for_book`
--

DROP TABLE IF EXISTS `ask_for_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ask_for_book` (
  `bookid` int(11) NOT NULL AUTO_INCREMENT,
  `bookName` varchar(45) NOT NULL,
  `price` varchar(45) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `ISBN` varchar(45) NOT NULL,
  `picUrl` varchar(45) NOT NULL,
  `askerId` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  PRIMARY KEY (`bookid`),
  KEY `_idx` (`askerId`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ask_for_book`
--

LOCK TABLES `ask_for_book` WRITE;
/*!40000 ALTER TABLE `ask_for_book` DISABLE KEYS */;
INSERT INTO `ask_for_book` VALUES (1,'编码理论与通信安全','50','最好有笔记','7302124639','images\\ask_for_books\\10.jpg',6,0),(2,'朝花夕拾','15','百年来温暖无数读者的经典散文名作，展现鲁迅先生温暖、童趣、欢喜的内心世界，恢复鲁迅亲手设计封面！大星文化出品','9787567584860','images\\ask_for_books\\26921942-1_w_5.jpg',3,1),(3,'骆驼祥子','20','原著无删减！还原老舍手稿定本！七年级指定必读！插图珍藏版，适合青少年阅读！','9787567578036','images\\ask_for_books\\25294213-1_w_6.jpg',3,2),(4,'城南旧事','20','20世纪中文小说百强之一，全新修订珍藏版！精选台湾文学“祖母级人物”林海音的成名作《城南旧事》和小说代表作《春风》《婚姻的故事》。大时代中的小故事，引领你重重温心底那段柔软的时光。','9787214165961','images\\ask_for_books\\23808286-1_w_1.jpg',4,1),(5,'巴黎圣母院','25','人性的善与恶，外表的美与丑，法国文豪雨果的*之作，经典译本，体味刻骨铭心的爱情，领悟悲天悯人的普世价值','9787532778133','images\\ask_for_books\\25289198-1_w_3.jpg',4,2),(6,'呼啸山庄','25','艾米莉·勃朗特泣血神作 狂野而永恒的爱情经典 方平先生经典译文 艾辛贝全套经典木刻插图共四十余幅，极具收藏价值 ','9787532778355','images\\ask_for_books\\25289209-1_w_3.jpg',6,3),(7,'爱的教育','20','作者:[意] 亚米契斯 著 储蕾 译，出版社:上海译文出版社，出版时间:2018年06月 ','9787532778089','images\\ask_for_books\\25289195-1_w_3.jpg',6,4);
/*!40000 ALTER TABLE `ask_for_book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-18 22:30:03
