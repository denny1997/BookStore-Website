-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: bookweb
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `bookId` int(11) NOT NULL AUTO_INCREMENT,
  `bookName` varchar(45) NOT NULL,
  `oriPrice` int(11) NOT NULL,
  `curPrice` int(11) NOT NULL,
  `category` varchar(45) NOT NULL,
  `intro` varchar(200) NOT NULL,
  `ISBN` varchar(45) NOT NULL,
  `picUrl` varchar(45) NOT NULL,
  `sellerId` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  PRIMARY KEY (`bookId`),
  KEY `sellerId_idx` (`sellerId`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (1,'本草纲目',50,45,'4','八成新','9787519017569','images\\books\\1.jpg',6,1),(2,'史记',100,80,'1','精装版全新','9787567725348','images\\books\\2.jpg',6,1),(3,'三国演义',89,79,'1','三国演义全二册，精装典藏版','9787020008728','images\\books\\s1076932.jpg',6,1),(4,'瓦尔登湖',39,35,'1','中国屈原诗歌奖金奖得主、人民大学教授王家新领衔翻译，一字未删全新译本，靠口碑风靡全网！2019升级珍藏纪念版，新增10幅原创彩插，万字精彩导读注释、赠精美藏书票！大星文化出品','9787521701692','images\\books\\27850947-1_w_2.jpg',3,1),(5,'Java从入门到精通（第5版）',69,50,'2','297个应用实例+37个典型应用+30小时教学视频+海量开发资源库，丛书累计销量200多万册','9787302517597','images\\books\\26912981-1_w_4.jpg',3,6),(6,'孙子兵法--中华经典藏书（平装）',35,19,'3','(无障碍阅读，完整定本，国内唯美精典插图本，不可不读的国学精髓。一部军事著作，被奉为“武经之首”或“兵经”，作者孙武也被后人尊为“兵圣”。中国工商联推荐，美国西点军校指定阅读。) ','9787538692990','images\\books\\23691198-1_w_8.jpg',3,1),(7,'新东方 四级词汇词根+联想记忆法：乱序版',48,25,'4','俞敏洪四级绿宝书全新改版，依据新大纲收词，乱序编排，修订释义和例句，“词根+联想”助记，补充中学词汇、超纲词和新闻词汇。','9787511041203','images\\books\\25220925-1_w_3.jpg',4,1),(8,'聆听音乐（第七版）',128,100,'5','联合库客音乐，为本书配备在线音乐 耶鲁大学公开课教材，全美百余所院校采用 风靡全球 广受好评的音乐入门读物 一辈子欣赏音乐，从《聆听音乐》开始 精装彩印，制作精美','9787302497400','images\\books\\25572701-1_w_3.jpg',4,1);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-18 22:30:04
